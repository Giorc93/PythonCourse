import setuptools

setuptools.setup(

    name='CalculatorPackage',
    version='1.0',
    description='Basic Caclculator',
    author='Gio',
    author_email='Gio@gio.com',
    URL='www.gio.com.co',
    packages=setuptools.find_packages()

)
